from django.contrib import admin
from django.urls import path,include
from pollingwebsite import views
urlpatterns = [
    path('register/', views.home, name='register'),
    path('login/',views.home1,name='login'),
    path('',views.home2,name='polls')
    
]